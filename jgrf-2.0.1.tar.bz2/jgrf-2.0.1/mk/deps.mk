CFLAGS_JG = $(shell $(PKG_CONFIG) --cflags jg)

CFLAGS_PTHREAD := -pthread

PKGCONF_CHDR := libchdr
CFLAGS_CHDR = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_CHDR))
LIBS_CHDR = $(shell $(PKG_CONFIG) --libs $(PKGCONF_CHDR))

PKGCONF_EPOXY := epoxy
CFLAGS_EPOXY = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_EPOXY))
LIBS_EPOXY = $(shell $(PKG_CONFIG) --libs $(PKGCONF_EPOXY))

PKGCONF_FLAC := flac
CFLAGS_FLAC = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_FLAC))
LIBS_FLAC = $(shell $(PKG_CONFIG) --libs $(PKGCONF_FLAC))

PKGCONF_LIBCRYPTO := libcrypto
CFLAGS_LIBCRYPTO = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_LIBCRYPTO))
LIBS_LIBCRYPTO = $(shell $(PKG_CONFIG) --libs $(PKGCONF_LIBCRYPTO))

PKGCONF_LZO := lzo2
CFLAGS_LZO = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_LZO))
LIBS_LZO = $(shell $(PKG_CONFIG) --libs $(PKGCONF_LZO))

PKGCONF_SDL3 := sdl3
CFLAGS_SDL3 = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_SDL3))
LIBS_SDL3 = $(shell $(PKG_CONFIG) --libs $(PKGCONF_SDL3))

PKGCONF_VULKAN := vulkan
CFLAGS_VULKAN = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_VULKAN))
LIBS_VULKAN = $(shell $(PKG_CONFIG) --libs $(PKGCONF_VULKAN))

PKGCONF_ZLIB := zlib
CFLAGS_ZLIB = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_ZLIB))
LIBS_ZLIB = $(shell $(PKG_CONFIG) --libs $(PKGCONF_ZLIB))

PKGCONF_ZSTD := libzstd
CFLAGS_ZSTD = $(shell $(PKG_CONFIG) --cflags $(PKGCONF_ZSTD))
LIBS_ZSTD = $(shell $(PKG_CONFIG) --libs $(PKGCONF_ZSTD))

-include $(SOURCEDIR)/mk/core.mk
-include $(SOURCEDIR)/mk/miniz.mk
-include $(SOURCEDIR)/mk/samplerate.mk
-include $(SOURCEDIR)/mk/speexdsp.mk

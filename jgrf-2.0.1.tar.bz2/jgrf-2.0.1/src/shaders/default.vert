#version 450

layout(location = 0) in vec2 position;
layout(location = 1) in vec2 texcoord;

layout(location = 0) out vec2 texCoord;

void main() {
    texCoord = texcoord;
    gl_Position = vec4(position, 0.0, 1.0);
}
